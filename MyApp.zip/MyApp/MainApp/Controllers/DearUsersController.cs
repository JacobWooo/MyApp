﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MainApp.Models;

namespace MainApp.Controllers
{
    public class DearUsersController : Controller
    {
        private readonly MyDearUsersContext _context;

        public DearUsersController(MyDearUsersContext context)
        {
            _context = context;
        }

        // GET: DearUsers
        public async Task<IActionResult> Index()
        {
            return View(await _context.DearUsers.ToListAsync());
        }

        // GET: DearUsers/Details/5
        public async Task<IActionResult> Details(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dearUsers = await _context.DearUsers
                .FirstOrDefaultAsync(m => m.Id == id);
            if (dearUsers == null)
            {
                return NotFound();
            }

            return View(dearUsers);
        }

        // GET: DearUsers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: DearUsers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,PassWord,RadioInput,Checkbox,DropdownSelector,DatePicker")] DearUsers dearUsers)
        {
            if (ModelState.IsValid)
            {
                _context.Add(dearUsers);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(dearUsers);
        }

        // GET: DearUsers/Edit/5
        public async Task<IActionResult> Edit(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dearUsers = await _context.DearUsers.FindAsync(id);
            if (dearUsers == null)
            {
                return NotFound();
            }
            return View(dearUsers);
        }

        // POST: DearUsers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(long id, [Bind("Id,Name,PassWord,RadioInput,Checkbox,DropdownSelector,DatePicker")] DearUsers dearUsers)
        {
            if (id != dearUsers.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(dearUsers);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DearUsersExists(dearUsers.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(dearUsers);
        }

        // GET: DearUsers/Delete/5
        public async Task<IActionResult> Delete(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dearUsers = await _context.DearUsers
                .FirstOrDefaultAsync(m => m.Id == id);
            if (dearUsers == null)
            {
                return NotFound();
            }

            return View(dearUsers);
        }

        // POST: DearUsers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(long id)
        {
            var dearUsers = await _context.DearUsers.FindAsync(id);
            _context.DearUsers.Remove(dearUsers);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DearUsersExists(long id)
        {
            return _context.DearUsers.Any(e => e.Id == id);
        }
    }
}
