﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MainApp.Models
{
    public partial class DearUsers
    {
        public long Id { get; set; }

        [Required]
        public string Name { get; set; }

       
        [RegularExpression(@"([A-Z]{2,})([1-9]{1,})([\W\D]{3,})([a-z]{0,})"), StringLength(10000, MinimumLength = 6)]
        
        public string PassWord { get; set; }

        [Required]
        public string RadioInput { get; set; }

        [Required]
        public string Checkbox { get; set; }

        [Required]
        public string DropdownSelector { get; set; }

        [Required]
        public DateTime DatePicker { get; set; }
    }
}
